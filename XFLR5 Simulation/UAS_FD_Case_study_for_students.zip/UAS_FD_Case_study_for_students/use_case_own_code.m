% This is the Code for the use-case example of the flight dynamic class

%Step 1: Initialization 

%------longitudinal movement

Z_u_A = Z_u/U0
Z_alpha_A = Z_alpha/U0
Z_q_A = 1
Z_delta_e_A = Z_del_e/U0
M_u_A = M_u + M_alpha_dot*Z_u_A
M_alpha_A = M_alpha + M_alpha_dot*Z_alpha_A
M_q_A = M_q + M_alpha_dot*Z_q_A
M_delta_e_A = M_del_e + M_alpha_dot*Z_delta_e_A

% definiton of system matrix
A_long = [X_u,X_alpha,0,-g*cos(0);Z_u_A,Z_alpha_A,Z_q_A,-g*sin(0);M_u_A,M_alpha,M_q_A,0;0,0,1,0]


%computing of eigenvalues
eigenvalues_longitudinal_movement=eig(A_long)


%------lateral movement

Y_beta_A = Y_v/U0
Y_r_A = - 1 + Y_r/U0
N_beta_A = N_beta
N_p_A = N_p
N_r_e_A = N_r

% definiton of system matrix
A_lat = [Y_beta_A,0,Y_r_A,(g/U0)*cos(0);L_beta,L_p,L_r,0;N_beta_A,N_p_A,N_r_e_A,0;0,0,1,0]


%computing of eigenvalues
eigenvalues_lateral_movement=eig(A_lat)





%--------------------------------------
%
% Second question for approximated Function
%
%---------------------------------------

%----short period oscilation
systemmatrix_short_period = [Z_alpha_A, 1;M_alpha_A, M_q_A]
inputmatrix_short_period = [Z_delta_e_A;M_delta_e_A]
outputmatrix_short_period = [0,0;0,0]
transmission_matrix_short_period = [0;0]

sys = ss(systemmatrix_short_period, inputmatrix_short_period, outputmatrix_short_period, transmission_matrix_short_period)
eigenvalues_short_period =eig(systemmatrix_short_period)
frequency_and_damping_short_period = damp(sys)

%----phugoide oscilation
systemmatrix_phugoide = [X_u,-g; -Z_u_A, 0]
inputmatrix_phugoide= [X_del_e;-Z_delta_e_A]
outputmatrix_phugoide = [0,0;0,0]
transmission_phugoide = [0;0]

sys = ss(systemmatrix_phugoide, inputmatrix_phugoide, outputmatrix_phugoide, transmission_phugoide)
eigenvalues_phugoide =eig(systemmatrix_phugoide)
frequency_and_damping_phugoide = damp(sys)

%----dutch roll oscilation
systemmatrix_dutch_roll = [Y_beta_A,Y_r_A; N_beta_A, N_r_e_A]
inputmatrix_dutch_roll  = [X_del_e;-Z_delta_e_A]
outputmatrix_dutch_roll = [0,0;0,0]
transmission_dutch_roll = [0;0]

sys = ss(systemmatrix_dutch_roll, inputmatrix_dutch_roll, outputmatrix_dutch_roll, transmission_dutch_roll)
eigenvalues_dutch_roll = eig(systemmatrix_dutch_roll)
frequency_and_damping_dutch_roll = damp(sys)

%----spiral mode
spiral_euquation = -(((L_r_A*N_beta_A) - (L_beta_A*N_r_e_A ))/L_beta_A)
systemmatrix_spiral = [0,0; 0, spiral_euquation]
inputmatrix_spiral  = [0;0]
outputmatrix_spiral = [0,0;0,0]
transmission_spiral = [0;0]

sys = ss(systemmatrix_spiral, inputmatrix_spiral, outputmatrix_spiral, transmission_spiral)
eigenvalues_spiral = eig(systemmatrix_spiral)
frequency_and_damping__spiral = damp(sys)


%----roll mode

systemmatrix_roll = [0,0; 0, L_p]
inputmatrix_roll  = [0;0]
outputmatrix_roll = [0,0;0,0]
transmission_roll = [0;0]

sys = ss(systemmatrix_roll, inputmatrix_roll, outputmatrix_roll, transmission_roll)
eigenvalues_roll = eig(systemmatrix_roll)
frequency_and_damping_roll = damp(sys)


% --------- Transferfunction

%% longitudinal transferfucntion

B_long = [X_del_e; Z_delta_e_A;M_delta_e_A;0]
C_long = eye(4)
D_long = zeros(4,1)

sys_long = ss(A_long,B_long,C_long,D_long)
transferfunction_long = tf(sys_long)
step(transferfunction_long(2))


%% lateral transferfucntion

B_lat = [0,Y_del_r;L_del_a ,L_r_A; N_del_a,N_del_r; 0,0]
C_lat = eye(4)
D_lat = zeros(4,2)

sys_lat = ss(A_lat,B_lat,C_lat,D_lat)
transferfunction_lat = tf(sys_lat)
step(transferfunction_lat(1,2))
